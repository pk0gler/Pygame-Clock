Controller Module
-----------------

.. automodule:: kogler.clock_controller
    :members:
    :special-members: __init__
