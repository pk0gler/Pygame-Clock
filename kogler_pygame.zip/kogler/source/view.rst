View Module
-----------------

.. automodule:: kogler.clock_view
    :members:
    :special-members:
